from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .models import PortfolioItem
from django.http import HttpResponse


def portfolio(request):
    portfolio_items = PortfolioItem.objects.all()
    return render(request, 'portfolio.html', {'portfolio_items': portfolio_items})


def homepage(request):
    return render(request, 'portfolio.html')
