from django.urls import path
from rest_framework import routers

from . import views
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from .api import PortfolioItemViewSet

router = routers.DefaultRouter()
router.register('api/PortfolioItem', PortfolioItemViewSet, 'PortfolioItem')
urlpatterns = [
    path('portfolio/', views.portfolio, name='portfolio'),
    path('', views.homepage, name='homepage'),
]
