from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import ContactMessage, PortfolioItem


class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'message')


class PortfolioItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description', 'date', 'done')
    list_display_links = ('id', 'name')
    list_editable = ('done',)
    search_fields = ('name', 'description')
    list_filter = ('name', 'done')


admin.site.register(ContactMessage)
admin.site.register(PortfolioItem)


def site(request):
    return None
