from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import ContactMessage, PortfolioItem

admin.site.register(ContactMessage)
admin.site.register(PortfolioItem)


def site(request):
    return None