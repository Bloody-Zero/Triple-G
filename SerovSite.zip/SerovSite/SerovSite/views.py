import views
from django.urls import path

from django.shortcuts import render


def contact(request):
    return render(request, 'contact.html')


def index(request):
    return render(request, 'index.html')


def portfolio(request):
    return render(request, 'portfolio.html')


urlpatterns = [
    path('', index, name='index'),
    path('portfolio/', portfolio, name='portfolio'),
    path('contact/', contact, name='contact'),
]
